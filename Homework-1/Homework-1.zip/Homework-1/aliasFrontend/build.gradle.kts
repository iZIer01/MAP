group = rootProject.group
version = rootProject.version
